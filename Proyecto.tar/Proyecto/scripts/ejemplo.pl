#!/usr/bin/perl
use strict;



#Esta subrutina solo checa que el recurso solicitado contenga alguna palabra definida en la lista negra
    my $recurso=$ARGV[0];
    my $ip=$ARGV[1];
    my $tiempo=$ARGV[2];
    my $codigoRespuestao=$ARGV[3];
    my $log_ApacheError=$ARGV[4];
    my $listaNegra=$ARGV[5]."PathTransversal_blacklist.txt";
    my $rutaURL;
    my $variablesURL;
    my $tiempoError;
    my $linea;
    my $url;
    #Obteniendo variables de la URL
    # Ejemplo: /home/app.php?var1=a&?var2=b&?var3=c
    # Del ejemplo anterior se obtiene var1=a&?var2=b&?var3=c
    if($recurso =~ /.*\?(.*=.*)/ ){
	print "yes";
        $variablesURL=$2;
        #Analizamos si alguna variable es sospechosa
        open (LISTA, "$listaNegra") or die "ERROR: No se encuentra la lista negra : $listaNegra";
        while (<LISTA>) {
    	    $linea=$_;
	    chop ($linea);          
	    # Verificando que alguna variable contenga una palabra de la lista negra
	    if($variablesURL =~ /$linea/){
		#Hay una cadena sospechosa, se consulta si hay un error en la misma hora, ip, y recurso solicitado 
		open my $logError, '<',  $log_ApacheError or die "Could not open $log_ApacheError";
		#Se cambia el formato de la marca de tiempo ya que en el log de access es distinta a la de error
		$tiempo =~ m/([0-9]+)\/(.*)\/([0-9]+):(.*)/;
		$tiempoError=$2." ".($1)." ".$4. " ".$3;
		my @lines =  grep /.*$tiempoError.*$ip.*$recurso.*/i, <$logError>;
		print "Perl PT:";
		print @lines;
		print "\n". $recurso." ".$tiempo."\n";
	    }
        }
	close(LISTA);
    } 
    
    #Si el recurso no contiene variables obtenemos la ruta solicitada   
    #Ejemplo: /dir/dir1/../../../etc/passwd
    elsif($url =~ /(\/.*\/.+)/ ){
        if($url =~ /.*\.\.\// ){
	    print "Perl PT: " . $url." ".$tiempo."\n";
	}
    }



#	print "PT $_[0]\n";
#	return "Path Transversal return\n";
