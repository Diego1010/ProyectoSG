#!/usr/bin/perl
use strict;
#use warnings;

use scripts::XSS;
use scripts::PathTransversal;
use scripts::utilerias;



#Funcion para leer archivo de configuracion
sub parse_config_file {
    my ($config_line, $Name, $Value, $Config);
    my ($File, $Config) = @_;
    open (CONFIG, "$File") or die "ERROR: Config file not found : $File";
    while (<CONFIG>) {
        $config_line=$_;
        chop ($config_line);          # Remove trailling \n
        $config_line =~ s/^\s*//;     # Remove spaces at the start of the line
        $config_line =~ s/\s*$//;     # Remove spaces at the end of the line
        if ( ($config_line !~ /^#/) && ($config_line ne "") ){    # Ignore lines starting with # and blank lines
            ($Name, $Value) = split (/=/, $config_line);          # Split each line into name value pairs
            $$Config{$Name} = $Value;                             # Create a hash of the name value pairs
        }
    }
    close(CONFIG);
}


#Variables para leer el archivo de configuracion
my $config_file= $ENV{HOME}."/Proyecto/herramienta.conf";
my %Config = ();
utilerias::read_config_file($config_file, \%Config);
my $dirParsedApache=$Config{'parsedLogAccess'};
my $dirParsedApacheError=$Config{'parsedLogError'};
my $dirParsedPostgres=$Config{'parsedLogPostgres'};
my $dirListas=$Config{'rutaListas'};
my $toleranciaError=$Config{'toleranciaError'};
my $recurso;
my $nullFlag=0;
#En el archivo de configuracion usa el comodin  ~ en referencia al directorio HOME, Perl no puede interpretar la tilde como el directorio, para ello la sustituimos ~ por la variable de
#entorno de Perl  que contiene el directorio HOME del usuario

$dirParsedApache =~ s/^~(\w*)/$ENV{HOME}/e;
$dirParsedApacheError =~ s/^~(\w*)/$ENV{HOME}/e;
$dirParsedPostgres =~ s/^~(\w*)/$ENV{HOME}/e;
$dirListas =~ s/^~(\w*)/$ENV{HOME}/e;


my $log_Apache = $ARGV[0] or die "Leer log de apache\n";
my $log_ApacheError = $ARGV[1];
my $rutaAccess=$dirParsedApache.$log_Apache;
my @arreglo;
# Abrimos el archivo de los logs
open(my $data_acces, '<', $rutaAccess) or die "No se puede abrir el archivo $rutaAccess\n";
while (my $line1 = <$data_acces>)
{
    chomp $line1;
    # Obtenemos la informacion de la linea en un arreglo
    @arreglo= split (/;/, $line1);
	
    #$arreglo[0] = IP Cliente
    #$arreglo[1] = Fecha 05/Oct/2016:09:16:01
    #$arreglo[2] = Metodo HTTP
    #$arreglo[3] = Recurso
    #$arreglo[4] = Version HTTP
    #$arreglo[5] = Codigo de respuesta
    #$arreglo[6] = Tamanio de respuesta
    #$arreglo[7] = Referencia
    #$arreglo[8] = User-Agent

    #Checando que exista algun metodo
    if ($arreglo[2] ne "-"){
	$recurso=$arreglo[3];
	#Detectando si esta el caracter nulo codificado
        if($recurso =~ /%00/){
	    $nullFlag=1;
        }
	#Detectando si hay un caracter codificado
	if($recurso =~ /%[0-9|a-f|A-F][0-9|a-f|A-F]/){
		$recurso=utilerias::urlDecoder($recurso);		    
	}
        PathTransversal::analizarPT($recurso,$arreglo[1],$arreglo[5],$dirListas,$dirParsedApacheError,$log_ApacheError,$toleranciaError);
	XSS::analizarXSS($recurso,$arreglo[1],$arreglo[5],$dirListas,$dirParsedApacheError,$log_ApacheError,$toleranciaError);
    }

    $nullFlag=0;
}
    close $data_acces;

