#!/usr/bin/perl
use strict;

my %ips = ();
my @arreglo = ("ip","fecha","metodo","recurso","version","codigo","tamanio","referencia", "Mozilla/5.0 (iPhone; CPU iPhone OS 10_0_2 like Mac OS X) AppleWebKit/601.1 (KHTML, like Gecko) CriOS/53.0.2785.109 Mobile/14A456 Safari/601.1.46");
my $aux;



    #$arreglo[0] = IP Cliente
    #$arreglo[1] = Fecha 05/Oct/2016:09:16:01
    #$arreglo[2] = Metodo HTTP
    #$arreglo[3] = Recurso
    #$arreglo[4] = Version HTTP
    #$arreglo[5] = Codigo de respuesta
    #$arreglo[6] = Tamanio de respuesta
    #$arreglo[7] = Referencia
    #$arreglo[8] = User-Agent


if( exists($ips{$arreglo[0]} ) ){
	
	#Checando que exista el User-Agent
        if( exists($ips{$arreglo[0]}{$arreglo[8]} ) ){

	    #Checando que exista la fecha
            if( exists($ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]} ) ){
		$aux = $ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]};
		push(@$aux, " primero");
            }else{
		#No existe la fecha
		my @solicitudes;
                push(@solicitudes," primero fecha ");
                my %tiempo = ();
                $tiempo{$arreglo[1]} = \@solicitudes;
                $ips{$arreglo[0]}{$arreglo[8]} = \%tiempo;
            }

        }else{
	    #No existe el User-Agent
	    my @solicitudes;
            push(@solicitudes," primero U-A ");
            my %tiempo = ();
            $tiempo{$arreglo[1]} = \@solicitudes;
 	    my %userAgent= ();
            $userAgent{$arreglo[8]} = \%tiempo;
	    $ips{$arreglo[0]} = \%userAgent;
	}

    }else{
	my @solicitudes;
        push(@solicitudes,$arreglo[3]." ".$arreglo[5]);
        my %tiempo = ();
        $tiempo{$arreglo[1]} = \@solicitudes;
        my %userAgent= ();
        $userAgent{$arreglo[8]} = \%tiempo;
        $ips{$arreglo[0]} = \%userAgent;
        #print  $userAgent{$arreglo[8]}."\n";
        #print $ips{$arreglo[0]}."\n";
    }



    #$arreglo[0] = IP Cliente
    #$arreglo[1] = "Fecha 05/Oct/2016:09:16:01";
    #$arreglo[2] = Metodo HTTP
    #$arreglo[3] = Recurso
    #$arreglo[4] = Version HTTP
    #$arreglo[5] = Codigo de respuesta
    #$arreglo[6] = Tamanio de respuesta
    #$arreglo[7] = Referencia
    #$arreglo[8] = "User-Agent1";






if( exists($ips{$arreglo[0]} ) ){
	
	#Checando que exista el User-Agent
        if( exists($ips{$arreglo[0]}{$arreglo[8]} ) ){

	    #Checando que exista la fecha
            if( exists($ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]} ) ){
		$aux = $ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]};
		push(@$aux, " ultimo ");
            }else{
		#No existe la fecha
		my @solicitudes;
                push(@solicitudes," ultimo fecha ");
                my %tiempo = ();
                $tiempo{$arreglo[1]} = \@solicitudes;
                $ips{$arreglo[0]}{$arreglo[8]} = \%tiempo;
            }

        }else{
	    #No existe el User-Agent
	    my @solicitudes;
            push(@solicitudes," ultimo U-A ");
            my %tiempo = ();
            $tiempo{$arreglo[1]} = \@solicitudes;
 	    my %userAgent= ();
            $userAgent{$arreglo[8]} = \%tiempo;
	    $ips{$arreglo[0]} = \%userAgent;
	}

    }else{
	my @solicitudes;
        push(@solicitudes,$arreglo[3]." ".$arreglo[5]);
        my %tiempo = ();
        $tiempo{$arreglo[1]} = \@solicitudes;
        my %userAgent= ();
        $userAgent{$arreglo[8]} = \%tiempo;
        $ips{$arreglo[0]} = \%userAgent;
        #print  $userAgent{$arreglo[8]}."\n";
        #print $ips{$arreglo[0]}."\n";
    }

$aux = $ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]};
print "@$aux \n";
