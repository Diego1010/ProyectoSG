#!/usr/bin/perl
use strict;

my %ips = ();
my @arreglo = ("ip","fecha","metodo","recurso","version","codigo","tamanio","referencia", "User-Agent");
my $aux;



    #$arreglo[0] = IP Cliente
    #$arreglo[1] = Fecha 05/Oct/2016:09:16:01
    #$arreglo[2] = Metodo HTTP
    #$arreglo[3] = Recurso
    #$arreglo[4] = Version HTTP
    #$arreglo[5] = Codigo de respuesta
    #$arreglo[6] = Tamanio de respuesta
    #$arreglo[7] = Referencia
    #$arreglo[8] = User-Agent


if( exists($ips{$arreglo[0]} ) ){
	
	#Checando que exista el User-Agent
        if( exists($ips{$arreglo[0]}{$arreglo[8]} ) ){

	    #Checando que exista la fecha
            if( exists($ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]} ) ){
		$aux = $ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]};
		push(@$aux, " primero");
            }else{
		#No existe la fecha
		my @solicitudes;
                push(@solicitudes," primero fecha ");
                my %tiempo = ();
                $tiempo{$arreglo[1]} = \@solicitudes;
                $ips{$arreglo[0]}{$arreglo[8]} = \%tiempo;
            }

        }else{
	    #No existe el User-Agent
	    my @solicitudes;
            push(@solicitudes," primero U-A ");
            my %tiempo = ();
            $tiempo{$arreglo[1]} = \@solicitudes;
 	    my %userAgent= ();
            $userAgent{$arreglo[8]} = \%tiempo;
	    $ips{$arreglo[0]} = \%userAgent;
	}

    }else{
	my @solicitudes;
        push(@solicitudes,$arreglo[3]." ".$arreglo[5]);
        my %tiempo = ();
        $tiempo{$arreglo[1]} = \@solicitudes;
        my %userAgent= ();
        $userAgent{$arreglo[8]} = \%tiempo;
        $ips{$arreglo[0]} = \%userAgent;
        #print  $userAgent{$arreglo[8]}."\n";
        #print $ips{$arreglo[0]}."\n";
    }


$aux = $ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]};
push(@$aux, "otro");

print @$aux;

if( exists($ips{"ip"} ) ){
	
	#Checando que exista el User-Agent
        if( exists($ips{"ip"}{"User-Agent1"} ) ){

	    #Checando que exista la fecha
            if( exists($ips{"ip"}{"User-Agent1"}{"fecha1"} ) ){
		$aux = $ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]};
		push(@$aux, " ultimoUltimo");
            }else{
		#No existe la fecha
		my @solicitudes;
                push(@solicitudes," ultimo fecha ");
                my %tiempo = ();
                $tiempo{"fecha1"} = \@solicitudes;
                $ips{"ip"}{"User-Agent1"} = \%tiempo;
            }

        }else{
	    #No existe el User-Agent
	    my @solicitudes;
            push(@solicitudes," ultimo U-A ");
            my %tiempo = ();
            $tiempo{"fecha1"} = \@solicitudes;
 	    my %userAgent= ();
            $userAgent{"User-Agent1"} = \%tiempo;
	    $ips{"ip"} = \%userAgent;
	}

    }else{
	my @solicitudes;
        push(@solicitudes,$arreglo[3]." ".$arreglo[5]);
        my %tiempo = ();
        $tiempo{$arreglo[1]} = \@solicitudes;
        my %userAgent= ();
        $userAgent{$arreglo[8]} = \%tiempo;
        $ips{$arreglo[0]} = \%userAgent;
        #print  $userAgent{$arreglo[8]}."\n";
        #print $ips{$arreglo[0]}."\n";
    }



$aux = $ips{"ip"}{"User-Agent1"}{"fecha1"};

print @$aux;
