#!/bin/bash

#su  -c 'date 10092115' -
#ssh root@192.168.35.130 "date 10092115"
#ssh root@192.168.35.131 "date 10092115"


su  -c 'date --set="20161009 20:22:00"' -
ssh root@192.168.35.130 'date --set="20161009 20:22:00"'
ssh root@192.168.35.131 'date --set="20161009 20:22:00"'

date
ssh root@192.168.35.130 'date'
ssh root@192.168.35.131 'date'
