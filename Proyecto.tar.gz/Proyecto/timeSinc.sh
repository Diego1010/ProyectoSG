#!/bin/bash

su  -c 'date --set="20161012 01:44:00"' -
ssh root@192.168.35.130 'date --set="20161012 01:44:00"'
ssh root@192.168.35.131 'date --set="20161012 01:44:00"'

date
ssh root@192.168.35.130 'date'
ssh root@192.168.35.131 'date'
