#!/usr/bin/perl
use strict;

use Date::Parse;

#my $local_time = "Sat Mar 14 10:14:05 EDT 2015";
#my $local_time = "31/Dec/2016:23:59:59";
my $local_time = "Wed Oct 12 01:45:26 2016";

# 1426342445 will be stored in $unix_time

my $unix_time = str2time($local_time);
print "$unix_time\n";



my $datestring = localtime($unix_time);
print "Current date and time $datestring\n";

#$epoc = $epoc - 12 * 60 * 60;   # one day before of current date.
$unix_time = $unix_time + 1;   # one day before of current date.

$datestring = localtime($unix_time);
print "Yesterday's date and time $datestring\n";
