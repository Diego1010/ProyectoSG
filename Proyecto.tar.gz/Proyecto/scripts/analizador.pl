#!/usr/bin/perl
use strict;
#use warnings;

use scripts::XSS;
use scripts::PathTraversal;
use scripts::utilerias;
use scripts::Crawler;



#Variables para leer el archivo de configuracion
my $config_file= $ENV{HOME}."/Proyecto/herramienta.conf";
my %Config = ();
utilerias::read_config_file($config_file, \%Config);
my $dirParsedApache=$Config{'parsedLogAccess'};
my $dirParsedApacheError=$Config{'parsedLogError'};
my $dirParsedPostgres=$Config{'parsedLogPostgres'};
my $dirListas=$Config{'rutaListas'};
my $toleranciaError=$Config{'toleranciaError'};

#Datos para el crawler
my $frecPromPeticionSeg=$Config{'frecPromPeticionSeg'};
my $toleranciaSegundos=$Config{'toleranciaSegundos'};
my $duracionSeg=$Config{'duracionSeg'};

my $recurso;
my $recursoDecodificado;
my $nullFlag=0;
my $diagnostico;
my %ips;
my $refUserAgent;
my $refTiempo;
my $refSolicitudes;

#En el archivo de configuracion usa el comodin  ~ en referencia al directorio HOME, Perl no puede interpretar la tilde como el directorio, para ello la sustituimos ~ por la variable de
#entorno de Perl  que contiene el directorio HOME del usuario

$dirParsedApache =~ s/^~(\w*)/$ENV{HOME}/e;
$dirParsedApacheError =~ s/^~(\w*)/$ENV{HOME}/e;
$dirParsedPostgres =~ s/^~(\w*)/$ENV{HOME}/e;
$dirListas =~ s/^~(\w*)/$ENV{HOME}/e;


my $log_Apache = $ARGV[0] or die "Leer log de apache\n";
my $log_ApacheError = $ARGV[1];
my $rutaAccess=$dirParsedApache.$log_Apache;
my @arreglo;
# Abrimos el archivo de los logs
open(my $data_acces, '<', $rutaAccess) or die "No se puede abrir el archivo $rutaAccess\n";
while (my $line1 = <$data_acces>)
{
    chomp $line1;
    # Obtenemos la informacion de la linea en un arreglo
    @arreglo= split (/<-->/, $line1);
	
    #$arreglo[0] = IP Cliente
    #$arreglo[1] = Fecha 05/Oct/2016:09:16:01
    #$arreglo[2] = Metodo HTTP
    #$arreglo[3] = Recurso
    #$arreglo[4] = Version HTTP
    #$arreglo[5] = Codigo de respuesta
    #$arreglo[6] = Tamanio de respuesta
    #$arreglo[7] = Referencia
    #$arreglo[8] = User-Agent

    #Checando que exista algun metodo
    if ($arreglo[2] ne "-" && $arreglo[7] eq "-"){
	$recursoDecodificado="";
	$recurso=$arreglo[3];
	#Detectando si esta el caracter nulo codificado
        if($recurso =~ /%00/){
	    $nullFlag=1;
        }
	#Detectando si hay un caracter codificado
	if($recurso =~ /%[0-9|a-f|A-F][0-9|a-f|A-F]/){
		$recursoDecodificado=utilerias::urlDecoder($recurso);		    
	}
        #Si analizarPT devuelve 0, no encontro nada, si retorna 1 solo encontro un ataque PT en el access.log, si hay 2 encontro algo en el access.log y error.log
        $diagnostico = PathTraversal::analizarPT($recurso,$recursoDecodificado,$arreglo[1],$arreglo[5],$dirListas,$dirParsedApacheError,$log_ApacheError,$toleranciaError);
#	print "Resultado Path Transversal: $diagnostico\n";
#	print "Si el resultado es 0, no encontro nada, si es 1 solo encontro un ataque PT en el access.log, si es 2 encontro algo en el access.log y error.log\n";

	if($diagnostico == 0){
	    #Si analizarXSS devuelve 0, no encontro nada, si retorna 1 solo encontro un ataque XSS en el access.log, si hay 2 encontro algo en el access.log y error.log
	    $diagnostico = XSS::analizarXSS($recursoDecodificado,$arreglo[1],$arreglo[5],$dirListas,$dirParsedApacheError,$log_ApacheError,$toleranciaError);
#	    print "Resultado XSS: $diagnostico\n";
#	    print "Si el resultado es 0, no encontro nada, si es 1 solo encontro un ataque XSS en el access.log, si es 2 encontro algo en el access.log y error.log\n"

	}
#        if($diagnostico == 0 && $arreglo[7] eq "-" && ($recurso !~ /.*\?.*=.*/ || $recursoDecodificado !~ /.*\?.*=.*/ ) && ($recurso =~ /[a-z|0-9|\.\-_\/#]/i || $recursoDecodificado =~ /[a-z|0-9|\.\-_\/#]/i) ){
#        if($diagnostico == 0 && (  ($recursoDecodificado ne "" &&  $recursoDecodificado !~ /.*\?.*=.*/) || ($recursoDecodificado eq "" && $recurso !~ /.*\?.*=.*/) ) ){
        if($diagnostico == 0 && (  ($recursoDecodificado ne "" &&  $recursoDecodificado =~/^[a-z0-9\.\-_\/#]*$/i ) || ($recursoDecodificado eq "" && $recurso =~ /^[a-z0-9\.\-_\/#]*$/i ) ) ){

	    #Checando que exista la ip $arreglo[0]
	    if( exists($ips{$arreglo[0]} ) ){

		#Checando que exista el User-Agent $arreglo[8]
		if( exists($ips{$arreglo[0]}{$arreglo[8]} ) ){

            	    #Checando que exista la fecha $arreglo[1]
	            if( exists($ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]} ) ){
        	        $refSolicitudes = $ips{$arreglo[0]}{$arreglo[8]}{$arreglo[1]};
	                push(@$refSolicitudes, $arreglo[3]." ".$arreglo[5]);
            	    }else{
	                #No existe la fecha
        	        my @solicitudes =();
                	push(@solicitudes,$arreglo[3]." ".$arreglo[5]);
			$refTiempo= $ips{$arreglo[0]}{$arreglo[8]};
	       	        $$refTiempo{$arreglo[1]} = \@solicitudes;
}

        	}else{
	            #No existe el User-Agent $arreglo[8]
        	    my @solicitudes =();
	            push(@solicitudes,$arreglo[3]." ".$arreglo[5]);
		    my %tiempo = ();
                    $tiempo{$arreglo[1]} = \@solicitudes;
	            $refUserAgent = $ips{$arreglo[0]};
	            $$refUserAgent{$arreglo[8]} = \%tiempo;
	        }

	    }else{
		#No existe la ip $arreglo[0]
	        my @solicitudes = ();
        	push(@solicitudes,$arreglo[3]." ".$arreglo[5]);
	        my %tiempo = ();
        	$tiempo{$arreglo[1]} = \@solicitudes;
	        my %userAgent= ();
	        $userAgent{$arreglo[8]} = \%tiempo;
        	$ips{$arreglo[0]} = \%userAgent;
    	    }
        }
    }
    $nullFlag=0;
}
close $data_acces;

$diagnostico = Crawler::analizarCrawling(\%ips,$dirListas,$frecPromPeticionSeg,$toleranciaSegundos,$duracionSeg);

