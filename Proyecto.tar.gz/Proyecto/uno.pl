#!/usr/bin/perl

use Date::Parse;
 
#my $local_time = "Sat Mar 14 10:14:05 EDT 2015";
my $local_time = "13/Oct/2016:19:28:50";
 
# 1426342445 will be stored in $unix_time
my $unix_time = str2time($local_time);
print "$unix_time\n";
