#!/usr/bin/perl
use strict;


my $log="parsedLogs/errorApache/error.log1476399355";
my $consulta=".*Oct 13 17:55:07 2016.*etc\\/.*";
open my $logError, '<',  $log or die "No se encuentra el log de error Apache cuyo nombre es: $log";
my @lines =  grep /$consulta/i, <$logError>;
print "\n Perl PT Variable Grep: ".  @lines;

